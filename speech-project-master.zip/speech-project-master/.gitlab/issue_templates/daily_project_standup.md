# Project Standups
- Project title:
- Project Repository:
- Teams in the project:
- Project Leads:
 - Name1
 - Name2
- Project Coordinator:
- Meeting Details:
  - Regular meeting (Day and Time):
  - Medium:
  - Url:

## Minutes of Meetings
 - Date:
   - Work Status:
   - To Do:
   - Work division
   - Attendees:
   - Notes:

- Date:
   - Work Status:
   - To Do:
   - Work division:
   - Attendees:
   - Notes:
